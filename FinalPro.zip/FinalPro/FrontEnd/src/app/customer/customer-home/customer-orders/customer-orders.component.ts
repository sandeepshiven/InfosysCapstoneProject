import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { forEach } from "@angular/router/src/utils/collection";
import { Customer } from "src/app/shared/models/customer";
import { CustomerSharedService } from "../customer-shared-service";
import { CustomerOrdersService } from "./customer-orders.service";
import { Order } from "./order";

@Component({
  selector: "app-customer-orders",
  templateUrl: "./customer-orders.component.html",
  styleUrls: ["./customer-orders.component.css"],
})
export class CustomerOrdersComponent implements OnInit {
  customer: Customer;
  orderList: Order[] = [];
  finalOrderList: Order[] = [];
  status: string = "ALL";
  todayDate: Date = new Date();

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private customerOrderService: CustomerOrdersService
  ) {}

  ngOnInit() {
    this.customer = JSON.parse(sessionStorage.getItem("customer"));
    this.customerOrderService
      .getOrders(this.customer.emailId)
      .subscribe((orders) => {
        orders.forEach((order) => {
          order.dateOfDelivery = new Date(order.dateOfDelivery);
        });
        this.orderList = orders;
        this.finalOrderList = orders;
      });
  }

  changeStatus(newStatus: string) {
    this.finalOrderList = [];
    if (newStatus === "ALL") {
      this.finalOrderList = this.orderList;
      return;
    }
    for (let i = 0; i < this.orderList.length; i++) {
      if (newStatus === this.orderList[i].orderStatus) {
        // console.log(
        //   (this.todayDate - this.orderList[i].dateOfDelivery) /
        //     (1000 * 3600 * 24)
        // );
        this.finalOrderList.push(this.orderList[i]);
      }
    }
  }

  updateOrder(order: Order, status: string) {
    order.orderStatus = status;
    this.customerOrderService.updateOrder(order).subscribe();
  }
}
