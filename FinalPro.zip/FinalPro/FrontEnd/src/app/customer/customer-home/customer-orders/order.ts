import { PaymentThrough } from "src/app/shared/models/payment-through";
import { Product } from "src/app/shared/models/product";

export class Order {
  orderId: number;
  customerEmailId: string;
  orderNumber: number;
  dateOfOrder: Date;
  product: Product;
  quantity: number;
  totalPrice: number;
  addressId: number;
  errorMessage: string;
  orderStatus: string;
  paymentThrough: PaymentThrough;
  dateOfDelivery: Date;
}
