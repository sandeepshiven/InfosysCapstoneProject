import { Component, OnInit, Input, ElementRef } from "@angular/core";
import { Product } from "../../../../shared/models/product";
import { CustomerSharedService } from "../../customer-shared-service";
import { Cart } from "src/app/shared/models/cart";
import { Customer } from "src/app/shared/models/customer";
import { CustomerCartService } from "../../customer-cart/customer-cart.service";
import { WishlistService } from "../../wish-list/wishlist.service";

@Component({
  selector: "customer-product-details",
  templateUrl: "./customer-product-details.component.html",
  styleUrls: ["./customer-product-details.component.css"],
})
export class CustomerProductDetails implements OnInit {
  @Input()
  selectedProduct: Product;
  errorMessage: string;
  successMessage: string;
  favourite!: Boolean;
  notFavourite!: Boolean;
  addedToWishlist:boolean=false;
    customer: Customer;
    wishListProducts:any[];
  constructor(
    private customerCommonService: CustomerSharedService,
    private customerCartService: CustomerCartService, private wishService : WishlistService
  ) {}

  ngOnInit(): void {
    this.favourite = true;
    this.notFavourite = false;
    this.customer = JSON.parse(sessionStorage.getItem("customer"))//change
        this.wishListProducts = JSON.parse(sessionStorage.getItem("wishList"));
        for(let i of this.wishListProducts){
            if(this.selectedProduct.productId===parseInt(i.productId)){
                this.addedToWishlist=true;
                break;
            }
        }
  }

  addToCart() {
    this.successMessage = null;
    this.errorMessage = null;
    let cart: Cart[] = JSON.parse(sessionStorage.getItem("cart"));
    if (cart == null) {
      cart = [];
    }
    let customer: Customer = JSON.parse(sessionStorage.getItem("customer"));
    let cartToAdd: Cart = new Cart();
    cartToAdd.customerEmailId = customer.emailId;
    cartToAdd.quantity = 1;
    cartToAdd.product = this.selectedProduct;

    let alreadyAddedToCart: boolean =
      cart.filter((c) => c.product.productId == this.selectedProduct.productId)
        .length != 0;

    if (alreadyAddedToCart) {
      this.errorMessage =
        "Already added to Cart. Go to cart for modifying your selection.";
    } else {
      cart.push(cartToAdd);
      this.customerCommonService.updateCartList(cart);
      sessionStorage.setItem("cart", JSON.stringify(cart));
      this.customerCommonService.addProductToCart(cartToAdd).subscribe(
        (response) => {
          this.successMessage = response;
        },
        (error) => {
          this.errorMessage = error;
        }
      );
    }
  }
  addToWishlist(){
    //call backend to add 
    let xr = new Date();
     let req = {productId:this.selectedProduct.productId.toString(),userId:this.customer.emailId,date:xr.toLocaleDateString()};
    this.wishService.addProductToWishlist(req).subscribe(x=>{
     this.addedToWishlist=true;
     this.wishListProducts.push(req);
     this.customerCommonService.updateWishList(this.wishListProducts);
     sessionStorage.setItem("wishList", JSON.stringify(this.wishListProducts));
 },
 err=>{
     alert(err);
 })

}
removeFromWishlist(){
    //call backend to remove
    this.wishService.removeProductFromWishlist(this.selectedProduct.productId.toString(),this.customer.emailId).subscribe(x=>{
     this.addedToWishlist=false;
     this.wishListProducts = this.wishListProducts.filter((item) => item.productId !== this.selectedProduct.productId.toString());
     this.customerCommonService.updateWishList(this.wishListProducts);
     sessionStorage.setItem("wishList", JSON.stringify(this.wishListProducts));
 },
 err=>{
     alert(err)
 })
}
  changeFavourite() {
    if (this.favourite === true) {
      this.favourite = false;
      this.notFavourite = true;
    } else {
      this.favourite = true;
      this.notFavourite = false;
    }
  }
}
