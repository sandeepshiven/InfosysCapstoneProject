import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ViewAllProductsService } from './view-all-products.service';

import { Customer } from '../../../shared/models/customer';
import { Product } from '../../../shared/models/product';
import { CustomerSharedService } from '../customer-shared-service';
import { Router, ActivatedRoute } from '@angular/router';
import { Cart } from '../../../shared/models/cart';
import { WishlistService } from '../wish-list/wishlist.service';

@Component({
  selector: 'app-view-all-products',
  templateUrl: './view-all-products.component.html',
  styleUrls: ['./view-all-products.component.css']
})
export class ViewAllProductsComponent implements OnInit {

  successMessage: string;
  errorMessage: string;
  productList: Product[];

  searchText: string;

  viewDetails: boolean = false;
  selectedProduct: Product;

  addedToWishlist:boolean=false;
    customer: Customer;
    wishListProducts:any[];

  productListToDisplay: Product[] = [];
  constructor(private viewAllProductService: ViewAllProductsService,
    private customerCommonService: CustomerSharedService,
    private router: Router,
    private route: ActivatedRoute,
    private wishService : WishlistService) {

  }

  ngOnInit() {
    this.getAllProduct();
  }
  getAllProduct() {
    this.viewAllProductService.products$
      .subscribe(products => {
        this.productList = products;
        this.productListToDisplay = this.productList;
      },
      err=>{
        console.log(err)
      }
      );
      // console.log(this.productList)


  }
  setSelectedProduct(product: Product) {
    this.viewDetails = true;
    this.selectedProduct = product;
  }




  search(abc) {
    this.searchText=(this.searchText).toLocaleLowerCase();
    if (this.searchText) {
      this.productListToDisplay = this.productList.filter(product => {
        return product.brand.toLocaleLowerCase().indexOf(this.searchText) != -1 || product.name.toLocaleLowerCase().indexOf(this.searchText) != -1
      });
    } else {
      this.productListToDisplay = this.productList;
    }

  }

  clear() {
    this.productListToDisplay = this.productList;
    this.searchText = "";
  }

  addToCart(product: Product) {
    this.successMessage = '';
    this.errorMessage = '';
    let cart: Cart = new Cart();
    let customer: Customer = JSON.parse(sessionStorage.getItem("customer"));

    cart.customerEmailId = customer.emailId;
    cart.product = product;
    cart.quantity = 1;

    this.viewAllProductService.addToCart(cart).subscribe(
      cartFromDB => {
        this.successMessage = cartFromDB.successMessage;
      }, error => this.errorMessage = <any>error
    )
  }
  addToWishlist(){
    //call backend to add 
    let xr = new Date();
     let req = {productId:this.selectedProduct.productId.toString(),userId:this.customer.emailId,date:xr.toLocaleDateString()};
    this.wishService.addProductToWishlist(req).subscribe(x=>{
     this.addedToWishlist=true;
     this.wishListProducts.push(req);
     this.customerCommonService.updateWishList(this.wishListProducts);
     sessionStorage.setItem("wishList", JSON.stringify(this.wishListProducts));
    },
    err=>{
        alert(err);
    })

    }
    removeFromWishlist(){
        //call backend to remove
        this.wishService.removeProductFromWishlist(this.selectedProduct.productId.toString(),this.customer.emailId).subscribe(x=>{
        this.addedToWishlist=false;
        this.wishListProducts = this.wishListProducts.filter((item:Product) => item.productId !== this.selectedProduct.productId);
        this.customerCommonService.updateWishList(this.wishListProducts);
        sessionStorage.setItem("wishList", JSON.stringify(this.wishListProducts));
    },
    err=>{
        alert(err)
    })
    }

}
