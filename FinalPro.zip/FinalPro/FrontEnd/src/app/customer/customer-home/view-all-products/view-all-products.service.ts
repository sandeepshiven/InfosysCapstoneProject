import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { Product } from '../../../shared/models/product';

import { environment } from '../../../../environments/environment';

import { catchError } from 'rxjs/internal/operators/catchError';
import { Cart } from 'src/app/shared/models/cart';
import { ProductOnDeals } from 'src/app/shared/models/productOnDeals';

@Injectable({
  providedIn: 'root'
})
export class ViewAllProductsService {
  products$: Observable<Product[]>;
  constructor(private http: HttpClient) { }

  getAllProducts():void {
    let url = environment.CustomerProductAPI + "/getAllProducts";
    console.log(url)
    // console.log(url)
    this.products$ = this.http.get<Product[]>(url)
      .pipe(catchError(this.handleError));
  }

  getDealProducts(): Observable<ProductOnDeals[]> {

    let url = environment.CustomerProductAPI + "/getProductsOnDeal";
    return this.http.get<ProductOnDeals[]>(url)
      .pipe(catchError(this.handleError));

  }

  addToCart(cart: Cart): Observable<Cart> {
    // const url = environment.customerAPIUrl + '/customrLogin';
    return this.http.post<Cart>("http://localhost:8765/EKart/CustomerCartAPI/addProductToCart", cart)
      .pipe(catchError(this.handleError));

  }
  private handleError(err: HttpErrorResponse) {
    console.log("inside error")
    console.log(err)
    let errMsg:string='';
    if (err.error instanceof Error) {   
        errMsg=err.error.message;
        console.log(errMsg)
    }
     else if(typeof err.error === 'string'){
        errMsg=JSON.parse(err.error).message
    }
    else {
       if(err.status==0){ 
           errMsg="A connection to back end can not be established.";
       }else{
           errMsg=err.error.message;
       }
     }
        return throwError(errMsg);
}
}
