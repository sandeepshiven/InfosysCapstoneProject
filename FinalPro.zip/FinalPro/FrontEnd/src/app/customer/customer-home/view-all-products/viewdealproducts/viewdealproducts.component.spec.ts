import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewdealproductsComponent } from './viewdealproducts.component';

describe('ViewdealproductsComponent', () => {
  let component: ViewdealproductsComponent;
  let fixture: ComponentFixture<ViewdealproductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewdealproductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewdealproductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
