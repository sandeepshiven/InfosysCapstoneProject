import { Component, OnInit } from '@angular/core';

import { ViewAllProductsService } from './../view-all-products.service';

import { Customer } from '../../../../shared/models/customer';
import { Product } from '../../../../shared/models/product';
import { CustomerSharedService } from '../../customer-shared-service';
import { Router, ActivatedRoute } from '@angular/router';
import { Cart } from '../../../../shared/models/cart';
import { ProductOnDeals } from 'src/app/shared/models/productOnDeals';

@Component({
  selector: 'app-viewdealproducts',
  templateUrl: './viewdealproducts.component.html',
  styleUrls: ['./viewdealproducts.component.css']
})
export class ViewdealproductsComponent implements OnInit {

  successMessage: string;
  errorMessage: string;
  productList: ProductOnDeals[]=[];

  searchText: string;

  viewDetails: boolean = false;
  selectedProduct: Product;

  productListToDisplay: ProductOnDeals[] = [];

  constructor(private viewAllProductService: ViewAllProductsService,
    private sharedService: CustomerSharedService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    
      this.viewAllProductService.getDealProducts()
        .subscribe(products => {
          this.productList = products;
          console.log(this.productList);
          this.productListToDisplay = this.productList;
        }
        );

        
  
  
}

setSelectedProduct(product: Product) {
  this.viewDetails = true;
  this.selectedProduct = product;
}



addToCart(product: Product) {
  this.successMessage = '';
  this.errorMessage = '';
  let cart: Cart = new Cart();
  let customer: Customer = JSON.parse(sessionStorage.getItem("customer"));

  cart.customerEmailId = customer.emailId;
  cart.product = product;
  cart.quantity = 1;

  this.viewAllProductService.addToCart(cart).subscribe(
    cartFromDB => {
      this.successMessage = cartFromDB.successMessage;
    }, error => this.errorMessage = <any>error
  )
}




}