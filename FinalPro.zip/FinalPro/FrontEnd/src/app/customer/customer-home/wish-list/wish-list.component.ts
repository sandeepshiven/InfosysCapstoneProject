import { Component, OnInit } from '@angular/core';
import { Cart } from 'src/app/shared/models/cart';
import { Customer } from 'src/app/shared/models/customer';
import { Product } from 'src/app/shared/models/product';
import { CustomerSharedService } from '../customer-shared-service';
import { ViewAllProductsService } from '../view-all-products/view-all-products.service';
import { WishlistService } from './wishlist.service';

@Component({
  selector: 'app-wish-list',
  templateUrl: './wish-list.component.html',
  styleUrls: ['./wish-list.component.css']
})
export class WishListComponent implements OnInit {

  wishList:any[];
  wishListProducts:Product[];
  Products:Product[];
  idToDate:Map<string,string> = new Map();
  constructor(private wishService:WishlistService, private prodService : ViewAllProductsService, private customerSharedService : CustomerSharedService) { }
  loggedInCustomer:Customer;

  ngOnInit() {
     this.loggedInCustomer = JSON.parse(sessionStorage.getItem("customer"));
    this.wishService.getWishlist(this.loggedInCustomer.emailId).subscribe(x=>{
        this.wishList=x;
        console.log(x)
        sessionStorage.setItem("wishList", JSON.stringify(this.wishList));
    },
    err=>{
      console.log(err)
      alert(err)
    })
    this.prodService.products$.subscribe(products=>{
      this.Products=products
      console.log(products)
      this.prepareProduct()
    })
    
  }
  prepareProduct(){
    let ind=[];
    for(let i of this.wishList){
      ind.push(parseInt(i.productId ));
      this.idToDate.set(i.productId,i.date);
    }
    this.wishListProducts = this.Products.filter(x=>ind.indexOf(x.productId)>=0);
    console.log(this.wishListProducts)
  }
  addToCart(wish : Product){
    let cart:Cart[] = JSON.parse(sessionStorage.getItem("cart"));
        if(cart==null){
            cart = [];
        }
        
        let cartToAdd: Cart = new Cart();
        cartToAdd.customerEmailId = this.loggedInCustomer.emailId
        cartToAdd.quantity = 1;
        cartToAdd.product = wish;

        let alreadyAddedToCart:boolean = (cart.filter(c=>c.product.productId==wish.productId)).length != 0;
        
        if(alreadyAddedToCart){
            alert("Product Already Exist in Cart!")
        } else{
            cart.push(cartToAdd);
            this.customerSharedService.updateCartList(cart)
            sessionStorage.setItem("cart", JSON.stringify(cart));
            this.customerSharedService.addProductToCart(cartToAdd).subscribe((response)=>{
                console.log(response)
            }, (error)=>{
              alert(error)
            })
        }
  }
  removeFromWishlist(wish : Product){
    this.wishService.removeProductFromWishlist(wish.productId.toString(),this.loggedInCustomer.emailId).subscribe(x=>{
      console.log(x)
      this.wishListProducts = this.wishListProducts.filter((item:Product) => item.productId !== wish.productId);
      this.customerSharedService.updateWishList(this.wishListProducts);
      sessionStorage.setItem("wishList", JSON.stringify(this.wishListProducts));
    })
  }
}
