import { Component, OnInit } from '@angular/core';
import { SellerViewDealsService } from './seller-view-deals.service';
import { ProductOnDeals } from 'src/app/shared/models/productOnDeals';
import { Seller } from 'src/app/shared/models/seller';
import { Product } from 'src/app/shared/models/product';


@Component({
    selector: 'app-seller-view-deals',
    templateUrl: './seller-view-deals.component.html',
    styleUrls: ['./seller-view-deals.component.css']
})
export class SellerViewDealsComponent implements OnInit {
    p: number = 1;
    page: boolean = false;
    isProductSelected: boolean = false;
    selectedProduct: Product;
    productOnDeals: ProductOnDeals[];
    errorMessage: string;
    successMessage: string;

    constructor(private viewDealsService: SellerViewDealsService) { }

    seller: Seller;
    ngOnInit() {

        this.seller = this.getSellerFromSession();
        this.errorMessage = null;
        this.productOnDeals = null;
        this.successMessage = null;

        this.getAllDeals();

    }

    getAllDeals() {
        this.viewDealsService.getProductOnDeals(this.seller.emailId).subscribe(
            (response) => {
                this.productOnDeals = response;
                if (this.productOnDeals.length > 10) {
                    this.page = true
                }
            },
            (response) => {
                this.errorMessage = response.error.message;
                this.productOnDeals = null;
                this.successMessage = null;
                
            }
        )
    }

    removeFromDeals(productOnDeals: ProductOnDeals) {
        this.successMessage = null;
        this.errorMessage = null;

        this.viewDealsService.removeFromDeals(productOnDeals).subscribe(
            response => {
                this.successMessage = response.toString();
                this.getAllDeals();
            },

            response => {
                this.errorMessage = response.toString();
                this.getAllDeals();
            },

        )
    }

    getSellerFromSession() {
        return JSON.parse(sessionStorage.getItem("seller"))
    }

    setSelectedProduct(product: Product) {
        this.isProductSelected = true;
        this.successMessage = null;
        this.selectedProduct = product;
    }

    unsetSelectedProduct() {
        this.isProductSelected = false;
        this.selectedProduct = null;
    }

    isDealActive(productOnDeals: ProductOnDeals): boolean {
        let sysDateTime: Date = new Date();
        let currHour = sysDateTime.getHours();
        let currMin = sysDateTime.getMinutes();

        let endHour = productOnDeals.endDateTime[3];
        let endMin = productOnDeals.endDateTime[4];

        if (endHour<currHour)
            return false;
        else if(endHour === currHour && endMin<currMin)
            return false;

        return true;
    }
}