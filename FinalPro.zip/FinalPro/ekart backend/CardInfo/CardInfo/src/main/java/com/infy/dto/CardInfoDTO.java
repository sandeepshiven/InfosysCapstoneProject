package com.infy.dto;

public class CardInfoDTO {

	private String customerEmail;
	private Long cardNumber;
	private String expiryDate;
	private String name;

	public CardInfoDTO(String customerEmail, Long cardNumber, String expiryDate, String name) {
		super();
		this.customerEmail = customerEmail;
		this.cardNumber = cardNumber;
		this.expiryDate = expiryDate;
		this.name = name;
	}

	public CardInfoDTO() {
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public Long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(Long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
