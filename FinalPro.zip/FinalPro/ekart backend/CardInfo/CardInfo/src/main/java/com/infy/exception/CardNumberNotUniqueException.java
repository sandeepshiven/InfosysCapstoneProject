package com.infy.exception;

public class CardNumberNotUniqueException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CardNumberNotUniqueException(String message) {
		super(message);
	}
}
