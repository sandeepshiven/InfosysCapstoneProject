package com.infy.service;

import java.util.List;
import com.infy.dto.CardInfoDTO;

public interface CardInfoService {

	public boolean add(CardInfoDTO cardInfoDTO);

	public boolean delete(String customerEmail, Long cardNumber);

	public List<CardInfoDTO> view(String customerEmail);

}
