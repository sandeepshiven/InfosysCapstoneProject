package com.infy.ekart.model;

public class Customer {
	
	private String emailId;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Customer(String emailId) {
		super();
		this.emailId = emailId;
	}

	public Customer() {
		super();
	}
	
}
