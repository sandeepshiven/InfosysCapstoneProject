package com.infy.ekart.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.ekart.dao.OrderRepository;
import com.infy.ekart.entity.OrderEntity;
import com.infy.ekart.entity.ProductEntity;
import com.infy.ekart.model.Order;

@Service
public class OrderService {
	
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	ModelMapper modelMapper;
	
	public List<Order> getOrders(String email){
		
		List<OrderEntity> orderEntities = orderRepository.findByCustomerEmailId(email);
		
		List<Order> orders = new ArrayList<>(); 
		
		for(OrderEntity orderEntity : orderEntities) {
			orders.add(modelMapper.map(orderEntity, Order.class));
		}
		
		return orders;
	}
	
	public Order updateOrder(Order order) {
		
		OrderEntity orderEntity = modelMapper.map(order, OrderEntity.class);
		orderEntity.setProductEntity(modelMapper.map(order.getProduct(),ProductEntity.class));
		orderRepository.saveAndFlush(orderEntity);
		return order;
	}
	
	
}
