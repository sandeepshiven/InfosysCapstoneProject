package com.infy.ekart.dao;

import java.util.List;

import com.infy.ekart.model.Product;
import com.infy.ekart.model.ProductOnDeals;

public interface CustomerProductDAO {
	public List<Product> getAllProducts();
	public List<Product> getProductByCategory(String category);
	public List<ProductOnDeals> getProductsOnDeal() ;
}
