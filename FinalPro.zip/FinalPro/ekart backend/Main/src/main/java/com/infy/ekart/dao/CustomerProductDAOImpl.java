package com.infy.ekart.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.ekart.entity.ProductEntity;
import com.infy.ekart.entity.ProductOnDealsEntity;
import com.infy.ekart.model.Product;
import com.infy.ekart.model.ProductOnDeals;
import com.infy.ekart.model.Seller;

@Repository(value = "customerProductDAO")
public class CustomerProductDAOImpl implements CustomerProductDAO {
	
	@Autowired
	private EntityManager entityManager;
	
	@Override
	public List<Product> getAllProducts() {

		Query query = entityManager.createQuery("select p from ProductEntity p");
		
		List<ProductEntity> productEntityList= query.getResultList();
		
		List<Product> listOfProducts = new ArrayList<Product>();
		for (ProductEntity productEntity : productEntityList) {
			Product product = new Product();
			product.setBrand(productEntity.getBrand());
			product.setCategory(productEntity.getCategory());
			product.setDescription(productEntity.getDescription());
			product.setName(productEntity.getName());
			product.setPrice(productEntity.getPrice());
			product.setProductId(productEntity.getProductId());
			product.setQuantity(productEntity.getQuantity());
			product.setDiscount(productEntity.getDiscount());

			listOfProducts.add(product);
		}
		return listOfProducts;
	}
	@Override
	public List<ProductOnDeals> getProductsOnDeal() {

		Query query = entityManager.createQuery("select p from ProductOnDealsEntity p");
		
		List<ProductOnDealsEntity> productEntityList= query.getResultList();
		
		List<ProductOnDeals> listOfProducts = new ArrayList<ProductOnDeals>();
		for (ProductOnDealsEntity productEntity : productEntityList) {
			
			Product product = productEntity.convertToProduct(productEntity.getProductEntity());
			
			Seller seller = productEntity.convertToSeller(productEntity.getSellerEntity());
			
			
			ProductOnDeals productdeal = new ProductOnDeals();
			productdeal.setDealId(productEntity.getDealId());
			//product.setProduct(productEntity.getProductEntity());
			productdeal.setDealDiscount(productEntity.getDealDiscount());
			productdeal.setStartDateTime(productEntity.getStartDateTime());
			productdeal.setEndDateTime(productEntity.getEndDateTime());
			//System.out.println(productEntity.getProductEntity());
			productdeal.setProduct(product);
			productdeal.setSeller(seller);
		

			listOfProducts.add(productdeal);
		}
		return listOfProducts;
	}
	
	@Override
	public List<Product> getProductByCategory(String category) {
		System.out.println(4);
		
		
		Query query = entityManager.createQuery("select p from ProductEntity p where p.category = '"+category+"' ");
		
		
		System.out.println(5);
		
		List<ProductEntity> productEntityList= query.getResultList();
		
		List<Product> listOfProducts = new ArrayList<Product>();
		for (ProductEntity productEntity : productEntityList) {
			Product product = new Product();
			product.setBrand(productEntity.getBrand());
			product.setCategory(productEntity.getCategory());
			product.setDescription(productEntity.getDescription());
			product.setName(productEntity.getName());
			product.setPrice(productEntity.getPrice());
			product.setProductId(productEntity.getProductId());
			product.setQuantity(productEntity.getQuantity());
			product.setDiscount(productEntity.getDiscount());

			listOfProducts.add(product);
		}
		
		return listOfProducts;
	}
}
