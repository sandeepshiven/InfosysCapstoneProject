package com.infy.ekart.dao;

import java.time.LocalDate;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.ekart.entity.ProductEntity;
import com.infy.ekart.entity.ProductOnDealsEntity;
import com.infy.ekart.entity.SellerEntity;
import com.infy.ekart.model.Product;
import com.infy.ekart.model.ProductOnDeals;
import com.infy.ekart.model.Seller;

@Repository(value = "sellerDealsDAO")
public class SellerDealsDAOImpl implements SellerDealsDAO{

	@Autowired
	private EntityManager entityManager;

	@Override
	public Integer addProductOnDeals(ProductOnDeals productOnDeals){
		ProductOnDealsEntity productOnDealsEntity = new ProductOnDealsEntity();

		ProductEntity productEntity=new ProductEntity();
		productEntity.setBrand(productOnDeals.getProduct().getBrand());
		productEntity.setCategory(productOnDeals.getProduct().getCategory());
		productEntity.setDescription(productOnDeals.getProduct().getDescription());
		productEntity.setDiscount(productOnDeals.getProduct().getDiscount());
		productEntity.setName(productOnDeals.getProduct().getName());
		productEntity.setPrice(productOnDeals.getProduct().getPrice());
		productEntity.setProductId(productOnDeals.getProduct().getProductId());
		productEntity.setQuantity(productOnDeals.getProduct().getQuantity());

		SellerEntity sellerEntity =  new SellerEntity();
		sellerEntity.setAddress(productOnDeals.getSeller().getAddress());
		sellerEntity.setEmailId(productOnDeals.getSeller().getEmailId());
		sellerEntity.setName(productOnDeals.getSeller().getName());
		sellerEntity.setPassword(productOnDeals.getSeller().getPassword());
		sellerEntity.setPhoneNumber(productOnDeals.getSeller().getPhoneNumber());


		productOnDealsEntity.setSellerEntity(sellerEntity);

		productOnDealsEntity.setProductEntity(productEntity);
		productOnDealsEntity.setDealDiscount(productOnDeals.getDealDiscount());

		productOnDealsEntity.setStartDateTime(productOnDeals.getStartDateTime());
		productOnDealsEntity.setEndDateTime(productOnDeals.getEndDateTime());

		entityManager.persist(productOnDealsEntity);

		return productOnDealsEntity.getDealId();
	}

	@Override
	public List<ProductOnDeals> getProductOnDeals(String emailId) {
		LocalDate today=LocalDate.now();
		LocalDate tomorrow=LocalDate.now().plusDays(1);
		Query query = entityManager.createQuery("select pd from ProductOnDealsEntity pd where pd.sellerEntity.emailId = :eId and pd.startDateTime> :sdt and pd.endDateTime<:edt");
		query.setParameter("eId", emailId);
		query.setParameter("sdt", today.atStartOfDay());
        query.setParameter("edt", tomorrow.atStartOfDay());
		List<ProductOnDealsEntity> productOnDealsEntities = query.getResultList();

		List<ProductOnDeals> productOnDeals = new ArrayList<ProductOnDeals>();

		if(!productOnDealsEntities.isEmpty()) {
			for(ProductOnDealsEntity pr : productOnDealsEntities) {
				ProductOnDeals pd = new ProductOnDeals();
				Product product = new Product();
				Seller seller = new Seller();
				pd.setDealDiscount(pr.getDealDiscount());
				pd.setDealId(pr.getDealId());
				pd.setStartDateTime(pr.getStartDateTime());
				pd.setEndDateTime(pr.getEndDateTime());

				product.setBrand(pr.getProductEntity().getBrand());
				product.setCategory(pr.getProductEntity().getCategory());
				product.setDescription(pr.getProductEntity().getDescription());
				product.setDiscount(pr.getProductEntity().getDiscount());
				product.setName(pr.getProductEntity().getName());
				product.setPrice(pr.getProductEntity().getPrice());
				product.setProductId(pr.getProductEntity().getProductId());
				product.setQuantity(pr.getProductEntity().getQuantity());

				pd.setProduct(product);

				seller.setAddress(pr.getSellerEntity().getAddress());
				seller.setPassword(pr.getSellerEntity().getPassword());
				seller.setEmailId(pr.getSellerEntity().getEmailId());
				seller.setName(pr.getSellerEntity().getName());
				seller.setPhoneNumber(pr.getSellerEntity().getPhoneNumber());

				pd.setSeller(seller);

				productOnDeals.add(pd);
			}
		}
		return productOnDeals;
	}

	@Override
	public Integer removeProductOnDeals(Integer dealId){

		ProductOnDealsEntity productOnDealsEntity=entityManager.find(ProductOnDealsEntity.class, dealId);
		Integer productId=productOnDealsEntity.getProductEntity().getProductId();
		if(productOnDealsEntity.getProductEntity()!=null) {
			productOnDealsEntity.setProductEntity(null);
		}
		if(productOnDealsEntity.getSellerEntity()!=null) {
			productOnDealsEntity.setSellerEntity(null);
		}

		entityManager.remove(productOnDealsEntity);

		return productId;
	}

	@Override
	public List<Product> getProductNotOnDeals(String emailId) {
		SellerEntity sellerEntity=entityManager.find(SellerEntity.class, emailId);
		List<ProductEntity> productEntities=sellerEntity.getProductEntities();
		List<Product> products=new ArrayList<Product>();
		List<Product> newProducts=new ArrayList<Product>();

		for(ProductEntity pe:productEntities) {
			Product p=new Product();
			p.setBrand(pe.getBrand());
			p.setCategory(pe.getCategory());
			p.setDescription(pe.getDescription());
			p.setDiscount(pe.getDiscount());
			p.setName(pe.getName());
			p.setPrice(pe.getPrice());
			p.setProductId(pe.getProductId());
			p.setQuantity(pe.getQuantity());
			products.add(p);
		}
		Query query = entityManager.createQuery("select pd from ProductOnDealsEntity pd where pd.sellerEntity.emailId = :eId");
		query.setParameter("eId", emailId);
		List<ProductOnDealsEntity> productOnDeals=query.getResultList();
		
		for(Product p:products) {
			boolean flag = false;
			for(ProductOnDealsEntity pd:productOnDeals) {
				if(p.getProductId() == pd.getProductEntity().getProductId()) {
					flag = true;
					break;
				}
			}
			
			if(!flag) {
				newProducts.add(p);
			}
		}

		return newProducts;
	}

}
