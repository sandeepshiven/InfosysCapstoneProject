package com.infy.ekart.entity;

import java.time.LocalDateTime;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.infy.ekart.model.Product;
import com.infy.ekart.model.Seller;
@Entity
@Table(name ="EK_DEALS_FOR_TODAY")
public class ProductOnDealsEntity {
         @Id
         @GeneratedValue(strategy= GenerationType.IDENTITY)
         private Integer dealId;
         @OneToOne(cascade = CascadeType.MERGE)
         @JoinColumn(name ="product_id", unique = true)
         private ProductEntity productEntity;
         private double dealDiscount;
         @Column(name ="deal_starts_at")
         private LocalDateTime startDateTime;
         @Column(name ="deal_ends_at")
         private LocalDateTime endDateTime;
         @OneToOne(cascade =CascadeType.MERGE)
         @JoinColumn(name ="seller_email_id",referencedColumnName = "email_id",unique=true)
         private SellerEntity sellerEntity;
		public Integer getDealId() {
			return dealId;
		}
		public void setDealId(Integer dealId) {
			this.dealId = dealId;
		}
		public ProductEntity getProductEntity() {
			return productEntity;
		}
		public void setProductEntity(ProductEntity productEntity) {
			this.productEntity = productEntity;
		}
		public double getDealDiscount() {
			return dealDiscount;
		}
		public void setDealDiscount(double dealDiscount) {
			this.dealDiscount = dealDiscount;
		}
		public LocalDateTime getStartDateTime() {
			return startDateTime;
		}
		public void setStartDateTime(LocalDateTime startDateTime) {
			this.startDateTime = startDateTime;
		}
		public LocalDateTime getEndDateTime() {
			return endDateTime;
		}
		public void setEndDateTime(LocalDateTime endDateTime) {
			this.endDateTime = endDateTime;
		}
		public SellerEntity getSellerEntity() {
			return sellerEntity;
		}
		public void setSellerEntity(SellerEntity sellerEntity) {
			this.sellerEntity = sellerEntity;
		}
		public Product convertToProduct(ProductEntity pe) {
			Product product =new Product();
			product.setBrand(pe.getBrand());
			product.setCategory(pe.getCategory());
			product.setDescription(pe.getDescription());
			product.setDiscount(pe.getDiscount());
			product.setName(pe.getName());
			//product.setErrorMessage(pe.getErrorMessage());
			product.setPrice(pe.getPrice());
			product.setProductId(pe.getProductId());
			product.setQuantity(pe.getQuantity());
			//product.setSellerEmailId(pe.getSellerEmailId());
			//product.setSuccessMessage(pe.getSuccessMessage());
			
			return product;
		}
		public Seller convertToSeller(SellerEntity se) {
		
			Seller seller = new Seller();
			seller.setName(se.getName());
			seller.setAddress(se.getAddress());
			seller.setEmailId(se.getEmailId());
			seller.setPhoneNumber(se.getPhoneNumber());
			
			
			return seller;
		}
         
}
