package com.infy.ekart.model;

import java.time.LocalDateTime;

public class ProductOnDeals {

	 private Integer dealId;
	 private Product product;
	 private double dealDiscount;
	 private LocalDateTime startDateTime;
	 private LocalDateTime endDateTime;
	 private Seller seller;
	public Integer getDealId() {
		return dealId;
	}
	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public double getDealDiscount() {
		return dealDiscount;
	}
	public void setDealDiscount(double dealDiscount) {
		this.dealDiscount = dealDiscount;
	}
	public LocalDateTime getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(LocalDateTime startDateTime) {
		this.startDateTime = startDateTime;
	}
	public LocalDateTime getEndDateTime() {
		return endDateTime;
	}
	public void setEndDateTime(LocalDateTime endDateTime) {
		this.endDateTime = endDateTime;
	}
	public Seller getSeller() {
		return seller;
	}
	public void setSeller(Seller seller) {
		this.seller = seller;

}
}
