package com.infy.ekart.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.ekart.dao.SellerDealsDAO;
import com.infy.ekart.model.Product;
import com.infy.ekart.model.ProductOnDeals;
import com.infy.ekart.validator.SellerDealsValidator;

@Service(value="sellerDealsService")
@Transactional
public class SellerDealsServiceImpl  implements SellerDealsService{
	@Autowired
	private SellerDealsDAO sellerDealsDAO;
	
	@Override
	public Integer addProductOnDeals(ProductOnDeals productOnDeals) throws Exception {
		
		SellerDealsValidator.validateProductForaddNewProductOnDeals(productOnDeals);
		
		return sellerDealsDAO.addProductOnDeals(productOnDeals);
	}
   @Override
	public List<ProductOnDeals> getProductOnDeals(String emailId) throws Exception {
		
		 List<ProductOnDeals> productOnDealsFromDB=sellerDealsDAO.getProductOnDeals(emailId);
	     if(productOnDealsFromDB==null || productOnDealsFromDB.isEmpty()) {
	         throw new Exception("SellerDealsService.NO_PRODUCT_ON_DEALS");
	     }
	     return productOnDealsFromDB;
	}

	@Override
	public Integer removeProductOnDeals(Integer dealId) throws Exception {

		return sellerDealsDAO.removeProductOnDeals(dealId);
	}

	@Override
	public List<Product> getProductNotOnDeals(String emailId) throws Exception {
		
		List<Product> products=sellerDealsDAO.getProductNotOnDeals(emailId);
		if(products.isEmpty()){
			throw new Exception("SellerDealsService.EVERY_PRODUCT_ON_DEALS");
		}
		return products;
	}

}
