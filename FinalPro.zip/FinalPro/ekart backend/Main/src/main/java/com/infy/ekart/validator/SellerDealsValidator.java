package com.infy.ekart.validator;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import com.infy.ekart.model.ProductOnDeals;

public class SellerDealsValidator {
	
	public static void validateProductForaddNewProductOnDeals(ProductOnDeals productOnDeals) throws Exception{
		if(!isValidSameDate(productOnDeals.getStartDateTime(), productOnDeals.getEndDateTime())) {
			throw new Exception("SellerDealsValidator.INVALID_SAMEDATE");
		}
		if(!isValidAfterToday(productOnDeals.getStartDateTime(), productOnDeals.getEndDateTime())) {
			throw new Exception("SellerDealsValidator.INVALID_AFTERTODAY");
		}
		if(!isValidWithinMonth(productOnDeals.getStartDateTime(), productOnDeals.getEndDateTime())) {
			throw new Exception("SellerDealsValidator.INVALID_WITHINMONTH");
		}
		if(!isValidEndTime(productOnDeals.getStartDateTime(), productOnDeals.getEndDateTime())) {
			throw new Exception("SellerDealsValidator.INVALID_ENDTIME");
		}
	}
	
	
	public static Boolean isValidSameDate(LocalDateTime startDateTime,LocalDateTime endDateTime) {
		if(startDateTime.toLocalDate().equals(endDateTime.toLocalDate())) {
			return true;
		}
		return false;
	}
	public static Boolean isValidAfterToday(LocalDateTime startDateTime,LocalDateTime endDateTime) {
		LocalDate dt=LocalDate.now();
		if(startDateTime.toLocalDate().isAfter(dt) && endDateTime.toLocalDate().isAfter(dt)) {
			return true;
		}
		return false;
	}
	public static Boolean isValidWithinMonth(LocalDateTime startDateTime,LocalDateTime endDateTime) {
		LocalDateTime dt=LocalDateTime.now();
		System.out.println(ChronoUnit.DAYS.between(dt, endDateTime));
		if(ChronoUnit.DAYS.between(dt, endDateTime)<=30) {
			return true;
		}
		return false;
	}
	public static Boolean isValidEndTime(LocalDateTime startDateTime,LocalDateTime endDateTime) {
		if(endDateTime.isAfter(startDateTime)) {
			return true;
		}
		return false;
	}
}