package com.infy.ekart.validator.test;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.infy.ekart.model.ProductOnDeals;
import com.infy.ekart.validator.SellerDealsValidator;


public class DealDateTimeValidatorTest {

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	@Test
	public void isValidSameDate()throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("SellerDealsValidator.INVALID_SAMEDATE");
		ProductOnDeals productOnDeals=new ProductOnDeals();
		LocalDate sdate=LocalDate.now().plusDays(1);
		productOnDeals.setStartDateTime(sdate.atStartOfDay());

		LocalDate edate=LocalDate.now().plusDays(2);
		productOnDeals.setEndDateTime(edate.atStartOfDay());
		SellerDealsValidator.validateProductForaddNewProductOnDeals(productOnDeals);

	}

	@Test
	public void isValidAfterToday()throws Exception{

		expectedException.expect(Exception.class);
		expectedException.expectMessage("SellerDealsValidator.INVALID_AFTERTODAY");
		ProductOnDeals productOnDeals=new ProductOnDeals();
		LocalDate sdate=LocalDate.now();
		productOnDeals.setStartDateTime(sdate.atStartOfDay());

		LocalDate edate=LocalDate.now();
		productOnDeals.setEndDateTime(edate.atStartOfDay());
		SellerDealsValidator.validateProductForaddNewProductOnDeals(productOnDeals);


	}


	@Test
	public void isValidWithinMonth()throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("SellerDealsValidator.INVALID_WITHINMONTH");
		ProductOnDeals productOnDeals=new ProductOnDeals();
		LocalDate sdate=LocalDate.now().plusDays(32);
		productOnDeals.setStartDateTime(sdate.atStartOfDay());

		LocalDate edate=LocalDate.now().plusDays(32);
		productOnDeals.setEndDateTime(edate.atStartOfDay());
		SellerDealsValidator.validateProductForaddNewProductOnDeals(productOnDeals);


	}

	@Test
	public void isValidEndTime()throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("SellerDealsValidator.INVALID_ENDTIME");
		ProductOnDeals productOnDeals=new ProductOnDeals();
		LocalDate sdate=LocalDate.now().plusDays(1);
		productOnDeals.setStartDateTime(sdate.atStartOfDay());

		LocalDate edate=LocalDate.now().plusDays(1);
		productOnDeals.setEndDateTime(edate.atStartOfDay());
		SellerDealsValidator.validateProductForaddNewProductOnDeals(productOnDeals);

	}

}

