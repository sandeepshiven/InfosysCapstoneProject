package com.wishlist.DTO;

import com.wishlist.entity.wishlistEntity;

public class wishlistDTO {
	private String userId;
	private String productId;
	private String date;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public static wishlistDTO toWishlistDTO(wishlistEntity wish) {
		wishlistDTO w = new wishlistDTO();
		w.setDate(wish.getDate());
		w.setProductId(wish.getProductId());
		w.setUserId(wish.getUserId());
		return w;
		
	}
	@Override
	public String toString() {
		return "wishlistDTO [userId=" + userId + ", productId=" + productId + ", date=" + date + "]";
	}
	
}
