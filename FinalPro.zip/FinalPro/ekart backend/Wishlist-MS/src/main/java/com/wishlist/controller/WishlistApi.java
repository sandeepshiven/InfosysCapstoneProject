package com.wishlist.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.wishlist.DTO.wishlistDTO;
import com.wishlist.service.wishlistService;

@RestController
@RequestMapping("/wishlist")
@CrossOrigin
public class WishlistApi {
	@Autowired
	wishlistService service;
	
	@PostMapping("/addProduct")
	public ResponseEntity<String> addToWishList(@RequestBody wishlistDTO req) throws Exception{
		try {
			String res = this.service.addToWishList(req);
			return new ResponseEntity<String>(res, HttpStatus.OK);			
		}
		catch(Exception ex) {
			if(ex.getMessage().equals("NotFound")) {
				throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Item already exist in the WishList!");
			}
			else throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
		}
	}
	
	@GetMapping("/{userId}")
	public List<wishlistDTO> getWishList(@PathVariable String userId)throws Exception {
		try {
			return this.service.getWishList(userId);			
		}
		catch(Exception ex) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
		}
	}
	
	@PostMapping("/deleteProduct")
	public ResponseEntity<String> deleteFromWishList(@RequestBody wishlistDTO req) throws Exception{
		try {
			String res = this.service.deleteFromWishList(req);
			return new ResponseEntity<String>(res, HttpStatus.OK);			
		}
		catch(Exception ex) {
			if(ex.getMessage().equals("NotFound")) {
				throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No Such Item Exist in the Wishlist!");
			}
			else  throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
		}
	}
}
