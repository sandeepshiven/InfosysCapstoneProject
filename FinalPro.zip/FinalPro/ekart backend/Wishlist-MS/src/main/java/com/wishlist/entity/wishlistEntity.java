package com.wishlist.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.wishlist.DTO.wishlistDTO;

@Entity
public class wishlistEntity {
	@Id
	@GeneratedValue(generator = "idGenerator", strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "user_id",nullable = false)
	private String userId;
	
	@Column(nullable=false)
	private String productId;
	
	@Column(nullable=false)
	private String date;
	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}



	public static wishlistEntity toWishlistEntity(wishlistDTO wish) {
		wishlistEntity w = new wishlistEntity();
		w.setDate(wish.getDate());
		w.setProductId(wish.getProductId());
		w.setUserId(wish.getUserId());
		return w;
	}

}
