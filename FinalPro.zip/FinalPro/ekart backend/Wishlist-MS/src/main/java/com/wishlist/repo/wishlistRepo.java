package com.wishlist.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.wishlist.entity.wishlistEntity;

public interface wishlistRepo extends JpaRepository<wishlistEntity, String> {

	@Query(nativeQuery = true,value="select * from wishlist_entity where wishlist_entity.USER_ID=?1")
	List<wishlistEntity> findByUserId(String userId);
	
	Optional<wishlistEntity> findByUserIdAndProductId(String userId,String productId);
	
//	@Modifying
//	@Query(nativeQuery = true,value="DELETE from wishlist_entity where wishlist_entity.USER_ID=?1 and wishlist_entity.PRODUCT_ID=?2")
//	void deleByUserIdAndProductId(String userId, String productId);
//	
}
