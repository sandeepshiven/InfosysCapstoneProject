package com.wishlist.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.wishlist.DTO.wishlistDTO;
import com.wishlist.entity.wishlistEntity;
import com.wishlist.repo.wishlistRepo;

@Service
public class wishlistService {
	
	@Autowired
	wishlistRepo wishDB;
	public String addToWishList(wishlistDTO req) throws Exception{
		Optional<wishlistEntity> wish =  this.wishDB.findByUserIdAndProductId(req.getUserId(),req.getProductId());
		if(wish.isPresent()) {
			throw new Exception("NotFound");			
		}
		else {
			try {
				wishlistEntity wishlistItem = wishlistEntity.toWishlistEntity(req);
				this.wishDB.saveAndFlush(wishlistItem);
				return "Item added Successfully";					
			}
			catch(Exception ex) {
				System.out.println(ex.getMessage());
				throw new Exception("Server Error! Please try in some time.");
			}
		}
	}
	
	public List<wishlistDTO> getWishList(String userId) throws Exception {
		try {
			List<wishlistEntity> list =   this.wishDB.findByUserId(userId);
			List<wishlistDTO> listDTO= new ArrayList<>();
			for(int i=0;i<list.size();i++) {
				listDTO.add(wishlistDTO.toWishlistDTO(list.get(i)));
			}			
			return listDTO;
		}
		catch(Exception ex) {
			throw new Exception("Server Error! Please try in some time.");
		}
	}
	
	public String deleteFromWishList(wishlistDTO req)throws Exception {
		
		Optional<wishlistEntity> wish =  this.wishDB.findByUserIdAndProductId(req.getUserId(),req.getProductId());
		if(wish.isPresent()) {
			try {
				System.out.println(wish.get());
				this.wishDB.delete(wish.get());
				return "Item Deleted Successfully";							
			}
			catch(Exception ex) {
				System.out.println(ex.getMessage());
				throw new Exception("Server Error! Please try in some time.");
			}
		}
		else {
			throw new Exception("NotFound");
		}
		
	}
}
 