import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerAddDealsComponent } from './seller-add-deals.component';

describe('SellerAddDealsComponent', () => {
  let component: SellerAddDealsComponent;
  let fixture: ComponentFixture<SellerAddDealsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerAddDealsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerAddDealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});