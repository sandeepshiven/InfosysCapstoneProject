import { TestBed } from '@angular/core/testing';

import { SellerViewDealsService } from './seller-view-deals.service';

describe('SellerViewDealsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SellerViewDealsService = TestBed.get(SellerViewDealsService);
    expect(service).toBeTruthy();
  });
});