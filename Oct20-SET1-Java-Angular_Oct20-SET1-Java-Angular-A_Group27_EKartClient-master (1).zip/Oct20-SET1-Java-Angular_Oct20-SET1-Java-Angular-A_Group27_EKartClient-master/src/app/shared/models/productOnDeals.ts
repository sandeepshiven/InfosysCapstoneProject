import { Product } from './product';
import { Seller } from './seller';

export class ProductOnDeals {
    dealId: number;
    product:Product;
    dealDiscount:number;
    startDateTime:Date;
    endDateTime:Date;
    seller:Seller;
    
}