import { TestBed } from '@angular/core/testing';

import { SellerAddDealsService } from './seller-add-deals.service';

describe('SellerAddDealsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SellerAddDealsService = TestBed.get(SellerAddDealsService);
    expect(service).toBeTruthy();
  });
});