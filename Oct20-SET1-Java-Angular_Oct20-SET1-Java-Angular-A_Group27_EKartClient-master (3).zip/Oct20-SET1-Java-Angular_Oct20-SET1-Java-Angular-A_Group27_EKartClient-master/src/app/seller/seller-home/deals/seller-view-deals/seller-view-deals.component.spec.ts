import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerViewDealsComponent } from './seller-view-deals.component';

describe('SellerViewDealsComponent', () => {
  let component: SellerViewDealsComponent;
  let fixture: ComponentFixture<SellerViewDealsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerViewDealsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerViewDealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});