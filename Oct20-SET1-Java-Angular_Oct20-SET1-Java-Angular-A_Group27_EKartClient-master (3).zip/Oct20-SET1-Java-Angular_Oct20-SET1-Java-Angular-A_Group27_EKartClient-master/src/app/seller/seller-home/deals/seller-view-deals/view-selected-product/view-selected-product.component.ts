import { Component, OnInit, Input } from '@angular/core';
import { Product } from 'src/app/shared/models/product';


 
@Component({
 selector: 'view-selected-product',
 templateUrl: './view-selected-product.component.html',
})
export class ViewSelectedProductComponent implements OnInit {
 
 @Input()
 selectedProduct: Product;

 dealPrice : number;
 constructor() {}
 
 ngOnInit() { 
    this.dealPrice = this.selectedProduct.price - (this.selectedProduct.price*this.selectedProduct.discount/100)
 }
 
 ngOnDestroy(){
 Object.assign(this.selectedProduct);
}
}